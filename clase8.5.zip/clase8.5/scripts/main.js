document.getElementById('product-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const productName = document.getElementById('productName').value;
    const productDescription = document.getElementById('productDescription').value;
    const productPrice = document.getElementById('productPrice').value;

    const product = {
        name: productName,
        description: productDescription,
        price: productPrice
    };

 //   console.log(productName + ' ' + productDescription + ' ' + productPrice );

    fetch('/api/products', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(product)
    })
    .then(response => response.json()) 
    .then(data => {
        if (data.success) {
            alert('Producto Registrado correctamente');
        } else {
            alert('Error al registrar el producto: ' + data.error);
        }
    })
    .catch(error => console.error('Error:', error));
});
