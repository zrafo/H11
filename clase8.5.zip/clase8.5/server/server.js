const express = require('express');
const bodyParser = require('body-parser');
const { saveProduct } = require('../database/database'); // Asegúrate de usar la ruta correcta a tu módulo de base de datos

const app = express();
const PORT = 3001; // Cambia a un puerto libre

// Middleware para analizar el cuerpo de las solicitudes
app.use(bodyParser.json());

// Servir archivos estáticos desde la carpeta raíz
app.use(express.static(__dirname + '/../'));

// Ruta para manejar la solicitud de registro de productos
app.post('/api/products', (req, res) => {
    const product = req.body;
    saveProduct(product)
        .then(() => res.json({ success: true }))
        .catch(err => res.json({ success: false, error: err.message }));
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
