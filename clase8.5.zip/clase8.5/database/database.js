const fs = require('fs');
const path = require('path');

const saveProduct = (product) => {
    return new Promise((resolve, reject) => {
        const productsPath = path.join(__dirname, 'products.json');

        fs.readFile(productsPath, (err, data) => {
            if (err && err.code !== 'ENOENT') {
                return reject(err);
            }

            let products = [];
            if (data && data.length > 0) {
                try {
                    products = JSON.parse(data);
                } catch (e) {
                    return reject(new Error('Failed to parse JSON data'));
                }
            }

            products.push(product);

            fs.writeFile(productsPath, JSON.stringify(products, null, 2), (err) => {
                if (err) {
                    return reject(err);
                }

                resolve();
            });
        });
    });
};

module.exports = {
    saveProduct
};
