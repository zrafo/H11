let nombre = "Juan";
let apellido = "Perez";
let edad = 30;
let esEstudiante = true;

// Concatenación de strings
let saludo = "Hola, " + nombre + " " + apellido + ". Tu edad es " + edad + ".";

// Cambio de tipo de dato
let edadstring = edad.toString();

// Uso de métodos de cadena
let nombremayusculas = nombre.toUpperCase();

``
// Mostrar resultados
document.getElementById("texto").innerHTML = `
    <strong>Saludo:</strong> ${saludo}<br>
    <strong>Edad como cadena:</strong> ${edadstring}<br>
    <strong>Nombre en mayúsculas:</strong> ${nombremayusculas}<br>
    <strong>Es estudiante:</strong> ${esEstudiante ? "Sí" : "No"}
`;



