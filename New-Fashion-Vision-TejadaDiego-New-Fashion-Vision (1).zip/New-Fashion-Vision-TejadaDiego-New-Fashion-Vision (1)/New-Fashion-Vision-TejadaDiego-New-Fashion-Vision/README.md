#New-Fashion-Vision
molleda: se agrego una nueva pagina llamada jovenes, donde se implementa animaciones de entrada de letra y un carrusel automatico, en la anterior pagina de inicio (index) se corrigieron errores y se mejoro la paleta de colores. 
Tejada: se agrego un dondo de degradados en la pagina de niños, se agrego que los catalogos de ropa, accesorios, zapatillas funcionen, se agrego que al pasar el cursor para navegar que cambie el color la pagina a do de desee ir el usuario, se agrego doble borde a los catalogos y a los productos se le añadio un borde.

